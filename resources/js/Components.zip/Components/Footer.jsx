import { SendHorizontal } from "lucide-react";

export default function Footer() {
    return (
        <footer>
            <div className="relative mt-8">
                <img
                    className="absolute inset-0 object-cover object-center w-full h-full"
                    src="/images/Platform/bg (2).webp"
                    alt=""
                />
                <div className="container relative px-4 py-12 mx-auto space-y-12 max-w-screeen-xl">
                    <h1 className="text-2xl font-bold text-center text-white md:text-4xl">
                        Experience the Power of <br /> Localized Monitoring
                    </h1>
                    <div className="flex justify-center">
                        <div className="grid grid-cols-1 gap-4 text-sm md:grid-cols-2">
                            <div>
                                <button className="w-full px-4 py-2 font-semibold text-white bg-blue-600 rounded-full">
                                    Request a Demo
                                </button>
                            </div>
                            <div>
                                <button className="w-full px-4 py-2 font-semibold text-blue-600 bg-white rounded-full">
                                    Contact Us for Deployment
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="relative p-4 text-white border-t border-t-white">
                <img
                    src="/images/Homepage/bg footer.webp"
                    className="absolute inset-0 object-cover object-center w-full h-full "
                    alt=""
                />
                <div className="absolute inset-0 w-full h-full bg-black bg-opacity-45"></div>
                <div className="container relative max-w-screen-xl py-8 mx-auto space-y-12">
                    <div className="flex flex-wrap items-center justify-between gap-8">
                        <div>
                            <img
                                className="object-contain size-24"
                                src="/images/Homepage/logo header.png"
                                alt=""
                            />
                        </div>
                        <div>
                            <h1 className="max-w-2xl text-base font-bold md:text-2xl">
                                Providing real-time weather, environmental, and
                                hydromet data to support safer, smarter, and
                                more resilient communities.
                            </h1>
                        </div>
                    </div>
                    <hr className="border border-[#8bd3cf]" />
                    <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4">
                        <div>
                            <ul className="space-y-2 text-[#8bd3cf] font-bold">
                                <li>Platform</li>
                                <li>News and Insight</li>
                                <li>About Us</li>
                            </ul>
                        </div>
                        <div className="space-y-4">
                            <ul className="space-y-2">
                                <li>Weather Stations and Sensors</li>
                                <li>Hydromet Platforms</li>
                                <li>Environmental Monitoring Software</li>
                                <li>Government and Research Platforms</li>
                            </ul>
                        </div>
                        <div className="space-y-4">
                            <h1 className="text-xl font-bold">
                                Subscribe to Our Newsletter
                            </h1>
                            <div className="flex items-center">
                                <input
                                    type="text"
                                    name=""
                                    id=""
                                    placeholder="Enter Email Address"
                                    className="bg-transparent border w-full rounded-full border-[#8bd3cf] text-sm"
                                />
                                <button className="p-2 border-b-2 border-[#8bd3cf]">
                                    Submit
                                </button>
                            </div>
                        </div>
                        <div className="space-y-4">
                            <span className="text-xl font-bold">
                                Social Media
                            </span>

                            <div>
                                <ul className="flex items-center space-x-4 list-inside">
                                    <li>
                                        <img
                                            className="object-contain size-12"
                                            src="/images/Homepage/icon - socmed/fb.webp"
                                            alt=""
                                        />
                                    </li>
                                    <li>
                                        <img
                                            className="object-contain size-12"
                                            src="/images/Homepage/icon - socmed/twitter.webp"
                                            alt=""
                                        />
                                    </li>
                                    <li>
                                        <img
                                            className="object-contain size-12"
                                            src="/images/Homepage/icon - socmed/instagram.webp"
                                            alt=""
                                        />
                                    </li>
                                    <li>
                                        <img
                                            className="object-contain size-12"
                                            src="/images/Homepage/icon - socmed/linkedin.webp"
                                            alt=""
                                        />
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div className="relative py-4 text-center text-white bg-blue-600">
                <div className="container max-w-screen-xl px-4 mx-auto">
                    <div className="flex flex-wrap justify-between gap-4">
                        <div>
                            <ul className="flex flex-wrap items-center gap-8">
                                <li>Terms & Conditions</li>
                                <li>Privacy Policy</li>
                            </ul>
                        </div>
                        <div>
                            <p>
                                Copyright &copy; {new Date().getFullYear()}{" "}
                                WEHLO. Designed & developed by{" "}
                                <a
                                    href="https://rwebsolutions.com.ph/"
                                    className="font-bold"
                                >
                                    R Web Solutions Corp
                                </a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    );
}
