export default function ApplicationLogo(props) {
    return (
        <img
            className="object-contain size-[6rem]"
            src="/images/Homepage/logo header.png"
            alt=""
        />
    );
}
