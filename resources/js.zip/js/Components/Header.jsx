import { Link, router } from "@inertiajs/react";
import { Search, LayoutGrid, Menu, X } from "lucide-react";
import { useState } from "react";

export default function Header() {
    const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
    const [searchOpen, setSearchOpen] = useState(false);
    const [searchQuery, setSearchQuery] = useState("");

    const handleSearch = (e) => {
        e.preventDefault();
        if (searchQuery.trim() !== "") {
            router.get("/blogs", { q: searchQuery });
            setSearchOpen(false);
            setSearchQuery("");
        }
    };

    return (
        <header className="fixed top-0 left-0 z-50 w-full bg-white">
            <nav className="container flex items-center justify-between p-4 mx-auto space-x-8 text-sm md:justify-center lg:space-x-16">
                {/* Left section */}
                <div className="flex items-center space-x-4 lg:space-x-8">
                    <Link href="/">
                        <img
                            className="block object-contain md:hidden size-14 lg:size-20"
                            src="/images/Homepage/logo header.png"
                            alt="Logo"
                        />
                    </Link>
                    {/* Desktop menu */}
                    <ul className="items-center hidden space-x-8 md:flex lg:space-x-16">
                        <li className="cursor-pointer">
                            {searchOpen ? (
                                <form
                                    onSubmit={handleSearch}
                                    className="relative"
                                >
                                    <input
                                        type="text"
                                        value={searchQuery}
                                        onChange={(e) =>
                                            setSearchQuery(e.target.value)
                                        }
                                        placeholder="Search..."
                                        className="px-2 py-1 text-sm border rounded-md"
                                        autoFocus
                                    />
                                    <button
                                        type="button"
                                        onClick={() => setSearchOpen(false)}
                                        className="absolute -translate-y-1/2 top-1/2 right-2"
                                    >
                                        <X size={16} />
                                    </button>
                                </form>
                            ) : (
                                <Search onClick={() => setSearchOpen(true)} />
                            )}
                        </li>
                        <li>
                            <Link href="/">Home</Link>
                        </li>
                        <li>
                            <Link href="/about_us">About Us</Link>
                        </li>
                        <li>
                            <Link href="/platform">Platform</Link>
                        </li>
                    </ul>
                </div>

                {/* Center logo for desktop */}
                <div className="hidden md:block">
                    <Link href="/">
                        <img
                            className="object-contain size-14 lg:size-20"
                            src="/images/Homepage/logo header.png"
                            alt="Logo"
                        />
                    </Link>
                </div>

                {/* Right section */}
                <div className="flex items-center space-x-2 lg:space-x-4">
                    <ul className="items-center hidden space-x-8 md:flex lg:space-x-16">
                        <li>
                            <Link href="/cases">Case Studies</Link>
                        </li>
                        <li>
                            <Link href="/blogs">News & Insights</Link>
                        </li>
                        <li>
                            <Link href="/contact_us">Contact Us</Link>
                        </li>
                    </ul>
                    <Menu
                        className="cursor-pointer md:hidden"
                        onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                    />
                </div>
            </nav>

            {/* Mobile dropdown menu */}
            {mobileMenuOpen && (
                <div className="px-4 pb-4 bg-white md:hidden">
                    <form onSubmit={handleSearch} className="mb-4">
                        <input
                            type="text"
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            placeholder="Search..."
                            className="w-full px-3 py-2 border rounded-md"
                        />
                    </form>
                    <ul className="space-y-3">
                        <li>
                            <Link href="/">Home</Link>
                        </li>
                        <li>
                            <Link href="/about_us">About Us</Link>
                        </li>
                        <li>
                            <Link href="/platform">Platform</Link>
                        </li>
                        <li>
                            <Link href="/cases">Case Studies</Link>
                        </li>
                        <li>
                            <Link href="/blogs">News & Insights</Link>
                        </li>
                        <li>
                            <Link href="/contact_us">Contact Us</Link>
                        </li>
                    </ul>
                </div>
            )}
        </header>
    );
}
