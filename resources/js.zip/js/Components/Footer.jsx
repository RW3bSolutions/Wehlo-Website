import { SendHorizontal } from "lucide-react";
import { useForm } from "@inertiajs/react";
import Swal from "sweetalert2";
import { Link } from "@inertiajs/react";
import AnimatedButton from "@/components/AnimatedButton";

export default function Footer() {
    const { data, setData, post, processing, errors, reset } = useForm({
        email_address: "",
    });
    return (
        <footer>
            <div className="relative mt-8">
                <img
                    className="absolute inset-0 object-cover object-center w-full h-full"
                    src="/images/Platform/bg (2).webp"
                    alt=""
                />
                <div className="container relative px-4 py-12 mx-auto space-y-12 max-w-screeen-xl">
                    <h1 className="text-2xl font-bold text-center text-white md:text-4xl">
                        Experience the Power of <br /> Localized Monitoring
                    </h1>
                    <div className="flex justify-center">
                        <div className="grid grid-cols-1 gap-4 text-base md:grid-cols-2">
                            <div>
                                <Link href="/contact_us">
                                    <AnimatedButton
                                        text="Request a Demo"
                                        className="w-full text-white bg-blue-600 hover:text-blue-600"
                                        bgColor="bg-white"
                                        textColor=""
                                    />
                                </Link>
                            </div>
                            <div>
                                <Link href="/contact_us">
                                    <AnimatedButton
                                        text="Contact Us for Deployment"
                                        className="w-full text-blue-600 bg-white hover:text-white"
                                        bgColor="bg-blue-600"
                                        textColor=""
                                    />
                                </Link>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="relative p-4 text-white border-t border-t-white">
                <img
                    src="/images/Homepage/bg footer.webp"
                    className="absolute inset-0 object-cover object-center w-full h-full "
                    alt=""
                />
                <div className="absolute inset-0 w-full h-full bg-black bg-opacity-45"></div>
                <div className="container relative max-w-screen-xl py-8 mx-auto space-y-12">
                    <div className="flex flex-wrap items-center justify-between gap-8">
                        <div>
                            <img
                                className="object-contain size-24"
                                src="/images/Homepage/logo header.png"
                                alt=""
                            />
                        </div>
                        <div>
                            <h1 className="max-w-2xl text-base font-bold md:text-2xl">
                                Providing real-time weather, environmental, and
                                hydromet data to support safer, smarter, and
                                more resilient communities.
                            </h1>
                        </div>
                    </div>
                    <hr className="border border-[#8bd3cf]" />
                    <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4">
                        <div>
                            <ul className="space-y-2 text-[#8bd3cf] font-bold">
                                <li>
                                    <Link href="/platform">Platform</Link>{" "}
                                </li>
                                <li>
                                    <Link href="/blogs">News and Insight</Link>
                                </li>
                                <li>
                                    <Link href="/about_us">About Us</Link>
                                </li>
                            </ul>
                        </div>
                        <div className="space-y-4">
                            <ul className="space-y-2">
                                <li>Weather Stations and Sensors</li>
                                <li>Hydromet Platforms</li>
                                <li>Environmental Monitoring Software</li>
                                <li>Government and Research Platforms</li>
                            </ul>
                        </div>
                        <div className="space-y-4">
                            <h1 className="text-xl font-bold">
                                Subscribe to Our Newsletter
                            </h1>
                            <form
                                onSubmit={(e) => {
                                    e.preventDefault();
                                    post(route("store.newsletter"), {
                                        preserveScroll: true,
                                        onSuccess: () => {
                                            Swal.fire({
                                                icon: "success",
                                                title: "Message Sent!",
                                                text: "We will get back to you shortly.",
                                                confirmButtonColor: "#3085d6",
                                            });
                                            reset();
                                        },
                                        onError: () => {
                                            Swal.fire({
                                                icon: "error",
                                                title: "Submission Failed",
                                                text: "Please check the form for errors.",
                                                confirmButtonColor: "#d33",
                                            });
                                        },
                                    });
                                }}
                            >
                                <div className="flex items-center">
                                    <input
                                        type="email"
                                        value={data.email_address}
                                        onChange={(e) =>
                                            setData(
                                                "email_address",
                                                e.target.value
                                            )
                                        }
                                        placeholder="Enter Email Address"
                                        className="bg-transparent border w-full rounded-full border-[#8bd3cf] text-sm"
                                    />

                                    <button
                                        type="submit"
                                        disabled={processing}
                                        className="p-2 border-b-2 border-[#8bd3cf]"
                                    >
                                        {processing ? "Sending..." : "Submit"}
                                    </button>
                                </div>

                                {errors.email_address && (
                                    <div className="text-sm text-red-500">
                                        {errors.email_address}
                                    </div>
                                )}
                            </form>
                        </div>
                        <div className="space-y-4">
                            <span className="text-xl font-bold">
                                Social Media
                            </span>

                            <div>
                                <ul className="flex items-center space-x-4 list-inside">
                                    <li>
                                        <img
                                            className="object-contain size-12"
                                            src="/images/Homepage/icon - socmed/fb.webp"
                                            alt=""
                                        />
                                    </li>
                                    <li>
                                        <img
                                            className="object-contain size-12"
                                            src="/images/Homepage/icon - socmed/twitter.webp"
                                            alt=""
                                        />
                                    </li>
                                    <li>
                                        <img
                                            className="object-contain size-12"
                                            src="/images/Homepage/icon - socmed/instagram.webp"
                                            alt=""
                                        />
                                    </li>
                                    <li>
                                        <img
                                            className="object-contain size-12"
                                            src="/images/Homepage/icon - socmed/linkedin.webp"
                                            alt=""
                                        />
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div className="relative py-4 text-center text-white bg-blue-600">
                <div className="container max-w-screen-xl px-4 mx-auto">
                    <div className="flex flex-wrap justify-between gap-4">
                        <div>
                            <ul className="flex flex-wrap items-center gap-8">
                                <li>Terms & Conditions</li>
                                <li>Privacy Policy</li>
                            </ul>
                        </div>
                        <div>
                            <p>
                                Copyright &copy; {new Date().getFullYear()}{" "}
                                WEHLO. Designed & developed by{" "}
                                <a
                                    href="https://rwebsolutions.com.ph/"
                                    className="font-bold"
                                >
                                    R Web Solutions Corp
                                </a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    );
}
