import { Link, Head } from "@inertiajs/react";
import MainLayout from "@/Layouts/MainLayout";
import { Dot, Search, Calendar } from "lucide-react";
import BannerSection from "@/components/BannerSection";
import React, { useEffect, useState } from "react";
import { usePage } from "@inertiajs/react";
import AnimatedButton from "@/components/AnimatedButton";

export default function Blogs() {
    const { query } = usePage().props; // Read the query param
    const initialSearch = query?.q || ""; // default to empty

    const [news, setNews] = useState([]);
    const [searchTerm, setSearchTerm] = useState(initialSearch);
    const [filteredNews, setFilteredNews] = useState([]);

    useEffect(() => {
        fetch("/news/data")
            .then((res) => res.json())
            .then((data) => {
                setNews(data.data);
                setFilteredNews(
                    data.data.filter((item) =>
                        item.title
                            .toLowerCase()
                            .includes(initialSearch.toLowerCase())
                    )
                );
            });
    }, []);

    useEffect(() => {
        const filtered = news.filter((item) =>
            item.title.toLowerCase().includes(searchTerm.toLowerCase())
        );
        setFilteredNews(filtered);
    }, [searchTerm, news]);

    return (
        <MainLayout>
            <Head title="Blogs" />
            <section>
                <div className="container relative max-w-screen-xl mx-auto">
                    <BannerSection
                        className="object-cover w-full h-full"
                        src="/images/Case Studies/banner.png"
                        alt="Case Studies Banner"
                    />

                    <div className="absolute bottom-0 left-4">
                        <h1 className="text-xs font-bold text-blue-700 md:text-5xl">
                            News & <br /> Insights
                        </h1>
                        <span className="text-xs">Home / News & Insights</span>
                    </div>
                </div>
            </section>

            <section>
                <div className="container max-w-screen-xl px-4 py-8 mx-auto">
                    <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
                        <div className="space-y-4 md:col-span-2">
                            <h1 className="text-3xl font-bold text-blue-700">
                                Stay Informed. Stay Ahead.
                            </h1>
                            <p>
                                Catch the latest updates, expert opinions, and
                                in-depth analyses on weather patterns,
                                environmental monitoring, and innovations from
                                the WEHLO community.
                            </p>
                        </div>

                        <div></div>

                        {/* Main Blog Posts */}
                        <div className="md:col-span-2">
                            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                                {Array.isArray(filteredNews) &&
                                    filteredNews.map((item, index) => {
                                        const formattedDate = new Date(
                                            item.created_at
                                        ).toLocaleDateString("en-US", {
                                            year: "numeric",
                                            month: "long",
                                            day: "numeric",
                                        });

                                        return (
                                            <div key={index}>
                                                <div className="bg-[#f1f1f1] gap-8 grid grid-cols-1 items-center p-4 rounded-2xl h-full w-full">
                                                    <div className="space-y-4">
                                                        <div>
                                                            <img
                                                                className="w-full h-[20rem] object-contain rounded-2xl"
                                                                src={item.image}
                                                                alt={
                                                                    item.title ||
                                                                    `News ${
                                                                        index +
                                                                        1
                                                                    }`
                                                                }
                                                                loading="lazy"
                                                            />
                                                        </div>
                                                        <div>
                                                            <span className="text-sm font-semibold text-blue-700">
                                                                {formattedDate}
                                                            </span>
                                                            <div className="text-xl font-bold">
                                                                {item.title}
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div>
                                                        <Link
                                                            href={`/blogs_details/${item.id}`}
                                                        >
                                                            <AnimatedButton
                                                                text="Read More"
                                                                className="text-blue-600 border border-blue-600 hover:text-white"
                                                                bgColor="bg-blue-600"
                                                                textColor=""
                                                            />
                                                        </Link>
                                                    </div>
                                                </div>
                                            </div>
                                        );
                                    })}
                                {filteredNews.length === 0 && (
                                    <p className="col-span-2 text-gray-500">
                                        No articles found.
                                    </p>
                                )}
                            </div>
                        </div>

                        {/* Sidebar */}
                        <div>
                            <div className="bg-[#f1f1f1] p-4 rounded-2xl space-y-4">
                                <h1 className="text-xl font-bold text-blue-700">
                                    Search For Anything
                                </h1>
                                <div className="relative flex items-center">
                                    <input
                                        type="text"
                                        className="w-full px-4 py-2 placeholder-gray-500 bg-white border border-blue-700 rounded-full"
                                        placeholder="Search here"
                                        value={searchTerm}
                                        onChange={(e) =>
                                            setSearchTerm(e.target.value)
                                        }
                                    />
                                    <div className="absolute text-blue-700 right-4">
                                        <Search />
                                    </div>
                                </div>
                                <hr className="border border-blue-700" />
                                <h1 className="text-2xl font-bold">
                                    Latest Posts
                                </h1>
                                {Array.isArray(news) &&
                                    news.slice(0, 3).map((item, index) => {
                                        const formattedDate = new Date(
                                            item.created_at
                                        ).toLocaleDateString("en-US", {
                                            year: "numeric",
                                            month: "short",
                                            day: "2-digit",
                                        });

                                        return (
                                            <div key={index}>
                                                <Link
                                                    href={`/blogs_details/${item.id}`}
                                                >
                                                    <div className="grid items-center grid-cols-3 gap-4 mb-4">
                                                        <div>
                                                            <img
                                                                className="object-contain w-40 h-24 rounded-xl"
                                                                src={item.image}
                                                                alt={item.title}
                                                            />
                                                        </div>
                                                        <div className="col-span-2 space-y-2 text-xs lg:text-base">
                                                            <div className="flex items-center space-x-2">
                                                                <Calendar className="text-blue-700" />
                                                                <span className="text-blue-700">
                                                                    {
                                                                        formattedDate
                                                                    }
                                                                </span>
                                                            </div>
                                                            <h1 className="text-base font-bold lg:text-lg line-clamp-2">
                                                                {item.title}
                                                            </h1>
                                                        </div>
                                                    </div>
                                                </Link>
                                            </div>
                                        );
                                    })}
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </MainLayout>
    );
}
